✅ MustafaMC Launcher Instructions:
- Put this folder into your .minecraft directory.
- Use TLauncher or any cracked launcher.
- Supports Fabric & Forge mods.
- Includes 60+ PvP, FPS, and Cosmetic mods.
- Custom background and UI.
