📦 MustafaMC Launcher v1.2

Made with love by Mustafa (Age 10) 🇵🇰
Visit: https://mustafa10mc.github.io

This is a clean launcher package with no executables.
