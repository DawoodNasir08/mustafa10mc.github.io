Welcome to MustafaMC Client v1.0!

This client includes:
- Cracked login support
- Cosmetics
- Fabric + Forge support
- PvP, FPS, and UI mods
- Lion + Islamic-themed UI

Enjoy your game!